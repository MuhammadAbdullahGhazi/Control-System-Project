As the name implies, temperature controller is a running program use to control the temperature for a desired set point. 
The temperature controller takes an input from a temperature sensor and then measure the output accordingly to the desired set point in order to reach the set point.
To accurately perform the process of temperature control without extra load or working temperature control system relays upon a controller known as PID controller. 
It compares the actual temperature, or desired set point, and then provide an output to a control element.

Objective:
The main objective of the project is to maintain the desired set temperature in a closed container. 
As we have the control system in which we are using PID to control the gain, PID controller is used to increase the intensity of heating and cooling element to reach the desired set point quicker.